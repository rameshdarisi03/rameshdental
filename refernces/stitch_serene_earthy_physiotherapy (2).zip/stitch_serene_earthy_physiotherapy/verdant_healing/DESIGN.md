---
name: Verdant Healing
colors:
  surface: '#fdf9ef'
  surface-dim: '#dddad0'
  surface-bright: '#fdf9ef'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3e9'
  surface-container: '#f2eee4'
  surface-container-high: '#ece8de'
  surface-container-highest: '#e6e2d8'
  on-surface: '#1c1c16'
  on-surface-variant: '#434843'
  inverse-surface: '#31312a'
  inverse-on-surface: '#f4f0e6'
  outline: '#737973'
  outline-variant: '#c3c8c1'
  surface-tint: '#4d6453'
  primary: '#061b0e'
  on-primary: '#ffffff'
  primary-container: '#1b3022'
  on-primary-container: '#819986'
  inverse-primary: '#b4cdb8'
  secondary: '#566342'
  on-secondary: '#ffffff'
  secondary-container: '#d7e5bb'
  on-secondary-container: '#5a6745'
  tertiary: '#261200'
  on-tertiary: '#ffffff'
  tertiary-container: '#422401'
  on-tertiary-container: '#b7895b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d0e9d4'
  primary-fixed-dim: '#b4cdb8'
  on-primary-fixed: '#0b2013'
  on-primary-fixed-variant: '#364c3c'
  secondary-fixed: '#dae8be'
  secondary-fixed-dim: '#becca3'
  on-secondary-fixed: '#141f05'
  on-secondary-fixed-variant: '#3f4b2c'
  tertiary-fixed: '#ffdcbd'
  tertiary-fixed-dim: '#f0bd8b'
  on-tertiary-fixed: '#2c1600'
  on-tertiary-fixed-variant: '#623f18'
  background: '#fdf9ef'
  on-background: '#1c1c16'
  surface-variant: '#e6e2d8'
typography:
  h1:
    fontFamily: Source Serif 4
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h1-mobile:
    fontFamily: Source Serif 4
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  h2:
    fontFamily: Source Serif 4
    fontSize: 36px
    fontWeight: '500'
    lineHeight: '1.3'
  h3:
    fontFamily: Source Serif 4
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
---

## Brand & Style

The design system is anchored in the concept of "Biophilic Restoration." It serves a high-end physiotherapy clientele by evoking the tranquility of a curated natural environment. The goal is to move away from the sterile, clinical coldness of traditional medicine toward a space that feels like a premium sanctuary for recovery.

The visual style is **Organic Minimalism**. It prioritizes heavy whitespace, a sophisticated earthy palette, and subtle tactile qualities that suggest human touch and care. The emotional response should be one of immediate physiological de-escalation: calm, grounded, and profoundly trustworthy.

## Colors

The palette is a tiered journey through a forest floor.
- **Deep Forest Green (Primary):** Used for primary actions and authoritative text. It represents stability and deep-rooted expertise.
- **Soft Sage (Secondary):** Used for supportive elements, background washes, and success states. It represents growth and healing.
- **Warm Clay (Tertiary):** An accent color used sparingly for highlights or call-to-actions that require warmth. It breaks the coolness of the greens with a human, tactile energy.
- **Sand & Paper (Neutrals):** The canvas of the design system. Avoid pure white (#FFFFFF) in favor of these off-white tones to reduce eye strain and reinforce the organic feel.

## Typography

This design system utilizes a "Humanist-Serif" pairing. 
- **Headlines:** Use **Source Serif 4**. Its scholarly yet elegant character provides the necessary professional authority for a medical brand while remaining warm and readable.
- **Body & Interface:** Use **Manrope**. It is a modern, high-legibility geometric sans-serif with soft terminals that mirror the organic roundedness of the brand.

Scale font weights carefully; avoid "Bold" (700+) in body text to maintain the soft aesthetic—prefer "Medium" (500) or "SemiBold" (600) for emphasis.

## Layout & Spacing

The layout philosophy is **Spacious & Balanced**. We use a 12-column fixed grid for desktop to ensure content remains centered and focused, preventing "information overwhelm."

- **Breathable Margins:** Use generous outer margins (64px+) on desktop to create a frame-like effect that isolates the content from the "noise" of the browser.
- **The 8px Rhythm:** All spacing between elements should be increments of 8px. However, for section-level vertical spacing, use larger leaps (80px, 120px, 160px) to give the eye significant rest periods.
- **Mobile Reflow:** On mobile, move to a 4-column grid with 20px margins. Stack elements vertically to maintain large, accessible touch targets for patients who may have limited mobility.

## Elevation & Depth

This design system avoids heavy drop shadows in favor of **Tonal Layering** and **Soft Ambient Occlusion**.

1.  **Base Layer:** The "Sand" neutral color serves as the background.
2.  **Surface Layer:** Cards and containers use a slightly lighter "Paper" color or a very subtle "Sage" tint to distinguish them from the background.
3.  **Depth:** Instead of shadows, use 1px solid borders in a slightly darker neutral (e.g., Clay-tinted grey) or a very soft, diffused shadow (Blur: 30px, Opacity: 4%) to lift high-priority items like modals or primary CTA buttons.
4.  **Glassmorphism:** Use subtle background blurs (12px) for sticky navigation bars to maintain a sense of environmental continuity as the user scrolls.

## Shapes

The shape language is inspired by **River Stones**. All corners are softened to remove the "sharpness" of clinical environments.

- **Buttons & Cards:** Use a 0.5rem (8px) base radius.
- **Large Sections/Images:** Use a 1.5rem (24px) radius to create a soft, window-like effect for photography.
- **Icons:** Icons should feature rounded caps and corners. Avoid jagged edges or 90-degree points.

## Components

- **Buttons:** Primary buttons should be Deep Forest Green with Sand text. Secondary buttons are outlined in Sage with Sage text. They should feel substantial—generous padding (16px top/bottom) is encouraged.
- **Cards:** Used for treatment types or therapist profiles. These should have a "Paper" background and a very subtle Clay-colored bottom border (2px) to add a grounded, earthy feel.
- **Inputs:** Text fields use a "Sand" fill with a 1px Sage border. On focus, the border transitions to Deep Forest Green. Labels should always be visible above the field.
- **Chips/Badges:** Use for filtering "Specialties" (e.g., Orthopedic, Sports). These should use a Soft Sage background with Forest Green text to maintain high legibility with an organic vibe.
- **Progress Indicators:** For patient recovery journeys, use smooth, rounded bars in Clay to signify progress and warmth.
- **Photography:** All imagery should feature soft, natural lighting, plants, and diverse human subjects in moments of calm or gentle movement.